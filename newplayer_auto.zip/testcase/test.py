# -*- coding: UTF-8 -*-
import datetime
import sys
import os

from cube.cube_manager import get_cube_client
from testcase.nsstest import enter_gamecenter_wait, exit_server, return_home, close_activity, team_prop_join_player, \
    auto_tuoguan, create_motorcade, steal_pig, skip_newer_tech, join_team_player, room_apply_jointeam,  dress, joinout_steal_pig, join_team3droom,Novice_Guidance,test_run,GameOutGuidance

reload(sys)
sys.setdefaultencoding("utf-8")
from wpyscripts.wetest.element import Element
from wpyscripts.wetest.engine import ElementBound

sys.path.append(os.path.abspath(os.path.join(os.getcwd(), "..")))

from testcase.tools import *
from wpyscripts.common.utils import *

def main():
    common_label = find_elment_wait("/UIRoot/C_Com_DialogCommon1/Anchor/Label")
    common_text = engine.get_element_text(common_label)
    print common_text
    if common_text == u'服务器连接失败，请您检查一下网络再试试':
        ensure_btn = find_elment_wait("/UIRoot/C_Com_DialogCommon1/Anchor/Button_Mid_Name(Yellow)")
        screen_shot_click(ensure_btn)
        print 1
    else:
        print 2


if __name__ == '__main__':
    Novice_Guidance()