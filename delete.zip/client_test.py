import os
import time
import json
import datetime
from datetime import timedelta

g_params = {
    "jobId": "",
    "buildId": "",
    "shell": ""
}


def params_init():
    with open("download.json", 'r') as soda_file:
        params = json.load(soda_file)
        global g_params
        g_params = params


def main():
    # start time
    start_time = datetime.datetime.now()

    # uninstall package
    os.popen("adb uninstall com.tencent.tmgp.speedmobile")

    # downlaod
    os.popen("python autodownload.py")

    # install
    params_init()
    time.sleep(10)
    apk_path = str(g_params["jobId"]) + "-" + str(g_params["buildId"])
    apk_name = ""
    files = os.listdir(apk_path)
    for file in files:
        apk_name = apk_path + "\\" + str(file)
    print apk_name
    os.popen("adb install " + apk_name)

    # auto test
    os.popen("python main.py --qqname=2980903152 --qqpwd=Test003 --engineport=50032 --uiport=19001")

    end_time = datetime.datetime.now()

    delta_times = end_time - start_time

    print "run time = " + str(delta_times)


if __name__ == '__main__':
    main()
