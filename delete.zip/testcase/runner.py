# -*- coding: UTF-8 -*-
from testcase.client_autotest import client_test, relax_profile, delte_account
from testcase.nsstest import team_prop_join_player

__author__ = 'minhuaxu'

from wpyscripts.tools.baisc_operater import *
import wpyscripts.tools.traverse.travel as travel

logger = manager.get_testcase_logger()


# 帮助文档及内容
# ==========================QQ登陆过程示例================================================
# def login_qq():
#     """
#         腾讯系游戏，通过QQ登陆
#
#         从拉起游戏出现QQ和微信登陆按钮--->QQ账号密码输入登陆-->登陆完成
#     :return:
#     """
#     tencent_login(scene_name="EmptyScene",login_button="/BootObj/CUIManager/Form_Login/LoginContainer/pnlMobileLogin/btnGroup/btnQQ",sleeptime=3)


# ==========================随机遍历过程================================================
# forbid_names = ["/ViewUIDepth_2/Canvas/ManagerInformation/Panel/JumpWindow/RightPanel/Wanjiaxinxi/ChangeServerButton",
#                 "/ViewUIDepth_2/Canvas/ManagerInformation/Panel/JumpWindow/RightPanel/Wanjiaxinxi/LoginOutButton"]
def random_search_test():
    log_dir = os.environ.get("UPLOADDIR")
    if log_dir:
        log_dir = os.path.join(log_dir, "policy.log")
    else:
        log_dir = "policy.log"
    logger.info("run random search in testcase runner")
    travel.explore(log_dir, [], mode=0, max_num=3000)


def run():
    """
        业务逻辑的起点
    """
    try:
        # team_prop_join_player()
        # client_test()
        # relax_profile()
        #
        delte_account()
    except Exception as e:
        traceback.print_exc()
        stack = traceback.format_exc()
        logger.error(stack)
        report.report_error("script_error")
    finally:
        report.screenshot()
