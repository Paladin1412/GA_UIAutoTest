#!/bin/bash
cd ${0%/*}
python main.py 1>stanrd.txt 2>err.txt 
